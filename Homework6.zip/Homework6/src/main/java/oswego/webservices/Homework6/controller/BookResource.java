package oswego.webservices.Homework6.controller;

import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import oswego.webservices.Homework6.api.Book;

import java.io.IOException;

@RestController
@RequestMapping("/book")
public class BookResource {

    //    @GetMapping("/{isbn:[0-9]+[x?[X?]]$}")
    @GetMapping("/{isbn}")
    public ResponseEntity<String> getBook(@PathVariable String isbn) throws IOException {
            Book book = Book.getBook(isbn);
            if(book!= null){
                String bs = book.toString();
                return new ResponseEntity<>(bs, HttpStatusCode.valueOf(200));
            }else {
                return new ResponseEntity<>( HttpStatusCode.valueOf(404));

            }

    }
}
