package oswego.webservices.Homework6.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import oswego.webservices.Homework6.api.Book;
import oswego.webservices.Homework6.api.User;
import oswego.webservices.Homework6.model.UserDAO;
import java.net.MalformedURLException;
import java.util.ArrayList;


@RestController
@RequestMapping("/user")
public class UserResource {
    private final UserDAO db;
    @Value("${book.url.customProperty}")
    private String bookUrl;

    @Autowired
    public UserResource(UserDAO db) {
        this.db = db;
    }


    @GetMapping(path="/{username}" )
    public ResponseEntity<ArrayList<Book>> getUserBookList(@PathVariable("username") String username ) throws MalformedURLException, JsonProcessingException {
        if(!username.isEmpty() ){
            if(db.findUserByUsername(username) != null){
                ArrayList<String> isbn_list = new ArrayList<>();
                for(User a : db.findIsbnByUsername(username)){
                    isbn_list.add(a.getIsbn());
                }
                User userWithBook_list = new User(username,  isbn_list);
                userWithBook_list.setBookUrl(bookUrl);
                return new ResponseEntity<>( userWithBook_list.getBook_list(), HttpStatusCode.valueOf(200));
            }
        }
        return new ResponseEntity<>( HttpStatusCode.valueOf(404));

    }
    @PostMapping(value = "/{username}/{isbn}", produces = "application/json")
    public ResponseEntity<User> addToBookList(@PathVariable("username") String username, @PathVariable("isbn") String isbn) {
       if(!username.isEmpty()  ){
           if(db.findUserByUsername(username) != null) {
               if (!isbn.isEmpty()) {
                   User user = new User(username, isbn);
                   db.save(user);
                   return new ResponseEntity<>(user, HttpStatusCode.valueOf(201));
               } else {
                   return new ResponseEntity<>(HttpStatusCode.valueOf(404));
               }
           }
       }
        return new ResponseEntity<>(HttpStatusCode.valueOf(404));
    }

    @Transactional
    @DeleteMapping(value = "/{username}/{isbn}", produces = "application/json")
    public ResponseEntity<User> removeBook(@PathVariable("username") String username, @PathVariable("isbn") String isbn) {
        if(!username.isEmpty() ){
            if(db.findUserByUsername(username) != null) {
                if (!isbn.isEmpty()) {
                    db.deleteByusernameAndIsbn(username, isbn);
                    return new ResponseEntity<>(new User(username, isbn), HttpStatusCode.valueOf(200));
                } else {
                    return new ResponseEntity<>(HttpStatusCode.valueOf(404));
                }
            }else {
                return new ResponseEntity<>(HttpStatusCode.valueOf(404));
            }

        }else {
            return new ResponseEntity<>(new User(username,isbn), HttpStatusCode.valueOf(401));
        }
    }

}
