package oswego.webservices.Homework6.controller;

import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import oswego.webservices.Homework6.api.Account;
import oswego.webservices.Homework6.model.AccountDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/account")
public class AccountResource {
    public final AccountDAO db;
    @Autowired
    public AccountResource(AccountDAO db) {
        this.db = db;
    }


    /**
     * Once auth is passes account is then checked to make sure it is acting on the account that was granted access
     * @param username the username from the uri
     * @return Response
     */
    @GetMapping(path ="/{username}", produces = "application/json")
    public ResponseEntity<Account>getAccountInfo(@PathVariable("username") String username){
        if(db.findById(username).isPresent()){
            return new ResponseEntity<>(db.findById(username).get(), HttpStatusCode.valueOf(200));
        }else {
            return new ResponseEntity<>(HttpStatusCode.valueOf(404));

        }


    }

    @PutMapping(path ="/{username}/{password}", produces ="application/json" )
    public ResponseEntity<Account> changeAccountPassword(@PathVariable("username") String username, @PathVariable("password") String password){
        if (!username.isEmpty() & !password.isEmpty() & db.findById(username).isPresent()){
           Account temp =  db.findById( username).get();
           temp.setPassword(password);
           db.save(temp);
            return new ResponseEntity<>(HttpStatusCode.valueOf(200));
        }else {
            return new ResponseEntity<>(HttpStatusCode.valueOf(401));
        }

    }

    @DeleteMapping(path = "/{username}", produces ="application/json" )
    public ResponseEntity<Account> deleteAccount(@PathVariable("username") String username){
        if(!username.isEmpty() ){
            db.delete(new Account(username));
            return new ResponseEntity<>(HttpStatusCode.valueOf(200));
        }else {
            return  new ResponseEntity<>(HttpStatusCode.valueOf(401));
        }

    }


}
