package oswego.webservices.Homework6.model;

import org.springframework.data.repository.CrudRepository;
import oswego.webservices.Homework6.api.Account;


public interface AccountDAO extends CrudRepository<Account, String> {


}
