package oswego.webservices.Homework6.api;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;

@Entity(name = "account")
@Table(name= "users")
public class Account {
    @Id
    @Column(name = "`user_name`")
    @JsonProperty
    private  String username;


    @Column(name="`user_pass`")
    @JsonProperty
    private String password;
    public Account(String username) {
        this.username = username;
    }
    public Account(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public Account() {

    }

    public  String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }



    @Override
    public String toString() {
        return String.format("{\"Username\":\"%s\" , \"Password\": \"%s\"}%n", username, password);
    }

}

