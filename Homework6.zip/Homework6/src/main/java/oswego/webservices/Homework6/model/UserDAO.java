package oswego.webservices.Homework6.model;

import org.springframework.data.repository.CrudRepository;
import oswego.webservices.Homework6.api.User;

public interface UserDAO extends CrudRepository<User, String> {
    User[] findIsbnByUsername(String username);
    void deleteByusernameAndIsbn(String username, String isbn);
    User findUserByUsername(String username);

}
