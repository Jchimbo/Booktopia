package oswego.webservices.Homework6.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import oswego.webservices.Homework6.api.Account;
import oswego.webservices.Homework6.model.AccountDAO;

import java.net.URI;

@RestController
@RequestMapping("/sign_Up")
public class SignUpResource {
    private final AccountDAO db;
    @Autowired
    public SignUpResource(AccountDAO db){
        this.db = db;
    }
    @PostMapping(produces = "application/json")
    public ResponseEntity<Account> createAccount(@RequestParam("username") String username, @RequestParam("password") String password){
       if(!username.isEmpty() & !password.isEmpty()){
           if(db.findById(username).isEmpty()){
               db.save(new Account(username, password));
               return ResponseEntity.created(URI.create("/user/"+username)).build();
           }else {
               return ResponseEntity.status(409).build();
           }
       }else {
           return ResponseEntity.status(404).build();
       }

    }
}
